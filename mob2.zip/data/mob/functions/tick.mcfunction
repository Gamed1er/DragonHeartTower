execute as @e run function mob:stream
function mob:floor_controller/mob_count_tick
execute if score tower control_panel matches 1.. run function mob:floor_enemey_summoner/main
scoreboard players add tick time 1
execute if score tick time matches 20 run scoreboard players set tick time 0
scoreboard players add 2tick time 1
execute if score 2tick time matches 40 run scoreboard players set 2tick time 0
scoreboard players set alive_player control_panel 0
execute unless entity @a[tag=!dead] unless score remain_mob_amount floor_controller matches 1.. run scoreboard players set now_wave enemy_wave_control 0
execute unless entity @a[tag=!dead] run kill @e[tag=enemy]
execute unless entity @a[tag=!dead] run scoreboard players set now_floor floor_controller 0
execute unless entity @a[tag=!dead] run function mob:floor_enemey_summoner/floor_lock_reset
execute unless entity @a[tag=!dead] run function mob:floor_controller/unlock_floor_0
execute unless entity @a[tag=!dead] as @a if score @s reborn_cd matches 2 run scoreboard players set floor floor_gen 0
execute unless entity @a[tag=!dead] as @a if score @s reborn_cd matches 1 run kill @e[type=item]
execute unless entity @a[tag=!dead] run function mob:floor_gen/main
execute unless entity @a[tag=!dead] run scoreboard players set @a[scores={reborn_cd=2..},tag=!in_dragon_pavilion] reborn_cd 1
execute if score alive_player control_panel matches 0 run scoreboard players set @a[scores={reborn_cd=2..},tag=!in_dragon_pavilion] reborn_cd 1