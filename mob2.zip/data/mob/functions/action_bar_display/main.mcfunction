execute as @s run scoreboard players operation @s player_stiff_display_percentage = @s stiff.bodylimit
execute as @s run scoreboard players operation @s player_stiff_display_percentage *= 100 math
execute as @s run scoreboard players operation @s player_stiff_display_percentage /= @s stiff.bodylimit.Max

execute as @s run scoreboard players operation @s player_mana_display_percentage = @s OMC.Player.Mana.Points
execute as @s run scoreboard players operation @s player_mana_display_percentage *= 100 math
execute as @s run scoreboard players operation @s player_mana_display_percentage /= @s OMC.Player.Mana.Points.Max

execute as @s if score @s player_stiff_display_percentage matches 0 run scoreboard players set @s player_hotbar_stiff_1 0
execute as @s if score @s player_stiff_display_percentage matches 1..30 run scoreboard players set @s player_hotbar_stiff_1 1
execute as @s if score @s player_stiff_display_percentage matches 31..60 run scoreboard players set @s player_hotbar_stiff_1 2
execute as @s if score @s player_stiff_display_percentage matches 61.. run scoreboard players set @s player_hotbar_stiff_1 3

execute as @s if score @s player_stiff_display_percentage matches 0..10 run scoreboard players set @s player_hotbar_stiff_2 0
execute as @s if score @s player_stiff_display_percentage matches 11..30 run scoreboard players set @s player_hotbar_stiff_2 1
execute as @s if score @s player_stiff_display_percentage matches 31..60 run scoreboard players set @s player_hotbar_stiff_2 2
execute as @s if score @s player_stiff_display_percentage matches 61.. run scoreboard players set @s player_hotbar_stiff_2 3

execute as @s if score @s player_stiff_display_percentage matches 0..20 run scoreboard players set @s player_hotbar_stiff_3 0
execute as @s if score @s player_stiff_display_percentage matches 21..30 run scoreboard players set @s player_hotbar_stiff_3 1
execute as @s if score @s player_stiff_display_percentage matches 31..60 run scoreboard players set @s player_hotbar_stiff_3 2
execute as @s if score @s player_stiff_display_percentage matches 61.. run scoreboard players set @s player_hotbar_stiff_3 3

execute as @s if score @s player_stiff_display_percentage matches 0..30 run scoreboard players set @s player_hotbar_stiff_4 0
execute as @s if score @s player_stiff_display_percentage matches 31..60 run scoreboard players set @s player_hotbar_stiff_4 2
execute as @s if score @s player_stiff_display_percentage matches 61.. run scoreboard players set @s player_hotbar_stiff_4 3

execute as @s if score @s player_stiff_display_percentage matches 0..40 run scoreboard players set @s player_hotbar_stiff_5 0
execute as @s if score @s player_stiff_display_percentage matches 41..60 run scoreboard players set @s player_hotbar_stiff_5 2
execute as @s if score @s player_stiff_display_percentage matches 61.. run scoreboard players set @s player_hotbar_stiff_5 3

execute as @s if score @s player_stiff_display_percentage matches 0..50 run scoreboard players set @s player_hotbar_stiff_6 0
execute as @s if score @s player_stiff_display_percentage matches 51..60 run scoreboard players set @s player_hotbar_stiff_6 2
execute as @s if score @s player_stiff_display_percentage matches 61.. run scoreboard players set @s player_hotbar_stiff_6 3

execute as @s if score @s player_stiff_display_percentage matches 0..60 run scoreboard players set @s player_hotbar_stiff_7 0
execute as @s if score @s player_stiff_display_percentage matches 61.. run scoreboard players set @s player_hotbar_stiff_7 3

execute as @s if score @s player_stiff_display_percentage matches 0..70 run scoreboard players set @s player_hotbar_stiff_8 0
execute as @s if score @s player_stiff_display_percentage matches 71.. run scoreboard players set @s player_hotbar_stiff_8 3

execute as @s if score @s player_stiff_display_percentage matches 0..80 run scoreboard players set @s player_hotbar_stiff_9 0
execute as @s if score @s player_stiff_display_percentage matches 81.. run scoreboard players set @s player_hotbar_stiff_9 3

execute as @s if score @s player_stiff_display_percentage matches 0..99 run scoreboard players set @s player_hotbar_stiff_10 0
execute as @s if score @s player_stiff_display_percentage matches 99.. run scoreboard players set @s player_hotbar_stiff_10 3

execute as @s if score @s player_mana_display_percentage matches 0 run scoreboard players set @s player_hotbar_mana_1 0
execute as @s if score @s player_mana_display_percentage matches 1..9 run scoreboard players set @s player_hotbar_mana_1 1
execute as @s if score @s player_mana_display_percentage matches 9.. run scoreboard players set @s player_hotbar_mana_1 2

execute as @s if score @s player_mana_display_percentage matches ..10 run scoreboard players set @s player_hotbar_mana_2 0
execute as @s if score @s player_mana_display_percentage matches 11..19 run scoreboard players set @s player_hotbar_mana_2 1
execute as @s if score @s player_mana_display_percentage matches 19.. run scoreboard players set @s player_hotbar_mana_2 2

execute as @s if score @s player_mana_display_percentage matches ..20 run scoreboard players set @s player_hotbar_mana_3 0
execute as @s if score @s player_mana_display_percentage matches 21..29 run scoreboard players set @s player_hotbar_mana_3 1
execute as @s if score @s player_mana_display_percentage matches 29.. run scoreboard players set @s player_hotbar_mana_3 2

execute as @s if score @s player_mana_display_percentage matches ..30 run scoreboard players set @s player_hotbar_mana_4 0
execute as @s if score @s player_mana_display_percentage matches 31..39 run scoreboard players set @s player_hotbar_mana_4 1
execute as @s if score @s player_mana_display_percentage matches 39.. run scoreboard players set @s player_hotbar_mana_4 2

execute as @s if score @s player_mana_display_percentage matches ..40 run scoreboard players set @s player_hotbar_mana_5 0
execute as @s if score @s player_mana_display_percentage matches 41..49 run scoreboard players set @s player_hotbar_mana_5 1
execute as @s if score @s player_mana_display_percentage matches 49.. run scoreboard players set @s player_hotbar_mana_5 2

execute as @s if score @s player_mana_display_percentage matches ..50 run scoreboard players set @s player_hotbar_mana_6 0
execute as @s if score @s player_mana_display_percentage matches 51..59 run scoreboard players set @s player_hotbar_mana_6 1
execute as @s if score @s player_mana_display_percentage matches 59.. run scoreboard players set @s player_hotbar_mana_6 2

execute as @s if score @s player_mana_display_percentage matches ..60 run scoreboard players set @s player_hotbar_mana_7 0
execute as @s if score @s player_mana_display_percentage matches 61..69 run scoreboard players set @s player_hotbar_mana_7 1
execute as @s if score @s player_mana_display_percentage matches 69.. run scoreboard players set @s player_hotbar_mana_7 2

execute as @s if score @s player_mana_display_percentage matches ..70 run scoreboard players set @s player_hotbar_mana_8 0
execute as @s if score @s player_mana_display_percentage matches 71..79 run scoreboard players set @s player_hotbar_mana_8 1
execute as @s if score @s player_mana_display_percentage matches 79.. run scoreboard players set @s player_hotbar_mana_8 2

execute as @s if score @s player_mana_display_percentage matches ..80 run scoreboard players set @s player_hotbar_mana_9 0
execute as @s if score @s player_mana_display_percentage matches 81..89 run scoreboard players set @s player_hotbar_mana_9 1
execute as @s if score @s player_mana_display_percentage matches 89.. run scoreboard players set @s player_hotbar_mana_9 2

execute as @s if score @s player_mana_display_percentage matches ..90 run scoreboard players set @s player_hotbar_mana_10 0
execute as @s if score @s player_mana_display_percentage matches 91..99 run scoreboard players set @s player_hotbar_mana_10 1
execute as @s if score @s player_mana_display_percentage matches 99.. run scoreboard players set @s player_hotbar_mana_10 2

execute as @s if score @s dodgeCD matches ..49 run scoreboard players set @s player_hotbar_dodge 0
execute as @s if score @s dodgeCD matches 50.. run scoreboard players set @s player_hotbar_dodge 1

execute as @s store result storage action_bar_displayer:function ID int 1 run scoreboard players get @s ID_system
execute as @s run function mob:action_bar_display/action_bar_store with storage action_bar_displayer:function
#scoreboard players set @s player_stiff_display_percentage 0
#scoreboard players set @s player_mana_display_percentage 1
#execute if score @s player_stiff_display_percentage matches 0 if score @s player_mana_display_percentage matches ..4 run execute as @s run title @s actionbar [{"text": "                         \uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7"},{"translate":"space.-80"},{"text": "\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00"}]
#execute if score @s player_stiff_display_percentage matches 0 if score @s player_mana_display_percentage matches 5..9 run execute as @s run title @s actionbar [{"text": "                         \uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff5"},{"translate":"space.-80"},{"text": "\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00"}]
#execute if score @s player_stiff_display_percentage matches 0 if score @s player_mana_display_percentage matches 10..14 run execute as @s run title @s actionbar [{"text": "                         \uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff3"},{"translate":"space.-80"},{"text": "\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00"}]
#execute if score @s player_stiff_display_percentage matches 0 if score @s player_mana_display_percentage matches 15..19 run execute as @s run title @s actionbar [{"text": "                         \uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff5\uEff3"},{"translate":"space.-80"},{"text": "\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00"}]
#execute if score @s player_stiff_display_percentage matches 0 if score @s player_mana_display_percentage matches 19..20 run execute as @s run title @s actionbar [{"text": "                         \uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff7\uEff3\uEff3"},{"translate":"space.-80"},{"text": "\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00\uEf00"}]
