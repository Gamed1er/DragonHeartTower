$execute as @s store result storage action_bar_displayer:function players.PC$(ID).mana_1 int 1 run scoreboard players get @s player_hotbar_mana_1
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).mana_2 int 1 run scoreboard players get @s player_hotbar_mana_2
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).mana_3 int 1 run scoreboard players get @s player_hotbar_mana_3
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).mana_4 int 1 run scoreboard players get @s player_hotbar_mana_4
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).mana_5 int 1 run scoreboard players get @s player_hotbar_mana_5
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).mana_6 int 1 run scoreboard players get @s player_hotbar_mana_6
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).mana_7 int 1 run scoreboard players get @s player_hotbar_mana_7
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).mana_8 int 1 run scoreboard players get @s player_hotbar_mana_8
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).mana_9 int 1 run scoreboard players get @s player_hotbar_mana_9
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).mana_10 int 1 run scoreboard players get @s player_hotbar_mana_10

$execute as @s store result storage action_bar_displayer:function players.PC$(ID).stiff_1 int 1 run scoreboard players get @s player_hotbar_stiff_1
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).stiff_2 int 1 run scoreboard players get @s player_hotbar_stiff_2
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).stiff_3 int 1 run scoreboard players get @s player_hotbar_stiff_3
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).stiff_4 int 1 run scoreboard players get @s player_hotbar_stiff_4
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).stiff_5 int 1 run scoreboard players get @s player_hotbar_stiff_5
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).stiff_6 int 1 run scoreboard players get @s player_hotbar_stiff_6
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).stiff_7 int 1 run scoreboard players get @s player_hotbar_stiff_7
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).stiff_8 int 1 run scoreboard players get @s player_hotbar_stiff_8
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).stiff_9 int 1 run scoreboard players get @s player_hotbar_stiff_9
$execute as @s store result storage action_bar_displayer:function players.PC$(ID).stiff_10 int 1 run scoreboard players get @s player_hotbar_stiff_10

$execute as @s store result storage action_bar_displayer:function players.PC$(ID).dodge int 1 run scoreboard players get @s player_hotbar_dodge

$execute as @s run function mob:action_bar_display/action_bar_display with storage action_bar_displayer:function players.PC$(ID)