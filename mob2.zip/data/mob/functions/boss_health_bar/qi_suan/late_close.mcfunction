
bossbar set qi_suan visible false