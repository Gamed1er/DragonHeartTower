execute as @s[tag=ToDH.enemy.Boss2,tag=boss,tag=!have_set_boss_bar] store result bossbar qi_suan max run attribute @s generic.max_health get

tag @s[tag=ToDH.enemy.Boss2,tag=boss,tag=!have_set_boss_bar] add have_set_boss_bar

execute as @s[tag=ToDH.enemy.Boss2,tag=boss] store result bossbar qi_suan value run data get entity @s Health

execute if entity @s[tag=ToDH.enemy.Boss2,tag=boss] run bossbar set qi_suan visible true

schedule function mob:boss_health_bar/qi_suan/late_close 2t replace