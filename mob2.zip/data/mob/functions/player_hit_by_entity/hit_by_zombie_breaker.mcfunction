effect give @s water_breathing 10 4
advancement revoke @s only mob:hit_by_zombie_breaker