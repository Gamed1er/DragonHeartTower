execute as @s[type=iron_golem] run function mob:boss_health_bar/qi_suan/main
execute as @s[tag=have_not_set_body_limit] run scoreboard players set @s stiff.bodylimit.Max 1000