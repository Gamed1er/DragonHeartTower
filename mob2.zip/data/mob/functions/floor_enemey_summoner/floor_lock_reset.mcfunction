
scoreboard players set floor_0_lock floor_lock 0
scoreboard players set floor_1_lock floor_lock 0
scoreboard players set floor_2_lock floor_lock 0
scoreboard players set floor_3_lock floor_lock 0
scoreboard players set floor_3_5_lock floor_lock 0
scoreboard players set floor_4_lock floor_lock 0
scoreboard players set floor_5_lock floor_lock 0
scoreboard players set floor_6_lock floor_lock 0
scoreboard players set floor_6_5_lock floor_lock 0
scoreboard players set floor_7_lock floor_lock 0
scoreboard players set floor_8_lock floor_lock 0
scoreboard players set floor_9_lock floor_lock 0
scoreboard players set floor_9_5_lock floor_lock 0
scoreboard players set floor_10_lock floor_lock 0