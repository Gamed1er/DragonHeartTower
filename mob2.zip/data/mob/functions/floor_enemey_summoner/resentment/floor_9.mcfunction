scoreboard players add now_wave enemy_wave_control 1

title @a[tag=!dead] times 1s 2s 1s
title @a[tag=!dead] title [{"color": "white","text": "["},{"italic": false,"bold": false,"color": "red","translate":"ToDH.title.double_elite"},{"color": "white","text": "]"}]

execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_9,tag=tower_1,sort=random,limit=1] at @s run function boss:soul_locker/story
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_9,tag=tower_1,sort=random,limit=1] at @s run function boss:flogger/story
title @a[tag=!dead] subtitle [{"color": "white","text": "["},{"italic": false,"bold": false,"translate":"ToDH.subtitle.double_elite","with":[{"selector":"@e[tag=soul_locker,limit=1]"},{"selector":"@e[tag=flogger,limit=1]"}]},{"color": "white","text": "]"}]