scoreboard players add now_wave enemy_wave_control 1

title @a[tag=!dead] times 1s 2s 1s
title @a[tag=!dead] title [{"color": "white","text": "["},{"italic": false,"bold": false,"color": "green","translate":"ToDH.title.wave","with":[{"score":{"name": "now_wave","objective": "enemy_wave_control"}}]},{"color": "white","text": "]"}]

execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/grudgeful_blood_zombie
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/poison_zombie
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/anger_skeletons
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/anger_skeletons
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/poison_zombie
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/grudgeful_blood_zombie
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/grudgeful_blood_zombie 
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/zombie_breaker
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/skeleton
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/skeleton
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/skeleton
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/zombie_breaker
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/skull_thrower
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/grudgeful_blood_zombie
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/grudgeful_evil_skeleton
execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/grudgeful_evil_skeleton 

execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/zombie
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/zombie
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/skeleton
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/skeleton
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/zombie_breaker
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/zombie
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/skeleton
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/skeleton
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/zombie_breaker
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/grudgeful_blood_zombie
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/grudgeful_blood_zombie
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/anger_skeletons
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/zombie_breaker 
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/grudgeful_evil_skeleton
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/grudgeful_evil_skeleton
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/poison_zombie
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/poison_zombie
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/grudgeful_blood_zombie
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/grudgeful_blood_zombie
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/skull_thrower
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/skull_thrower
execute if score now_wave enemy_wave_control matches 2 as @e[tag=mob_summon_point,tag=floor_5,tag=tower_1,sort=random,limit=1] at @s run function mob:summon_mob/anger_skeletons
