scoreboard players add now_wave enemy_wave_control 1

title @a[tag=!dead] times 1s 2s 1s
title @a[tag=!dead] title [{"color": "white","text": "["},{"italic": false,"bold": false,"color": "red","translate":"ToDH.title.elite"},{"color": "white","text": "]"}]

execute if score now_wave enemy_wave_control matches 1 as @e[tag=mob_summon_point,tag=floor_3,tag=tower_1,sort=random,limit=1] at @s run function boss:soul_locker/story
title @a[tag=!dead] subtitle [{"color": "white","text": "["},{"italic": false,"bold": false,"selector":"@e[tag=soul_locker,limit=1]"},{"color": "white","text": "]"}]