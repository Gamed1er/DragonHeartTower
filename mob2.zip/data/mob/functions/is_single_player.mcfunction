scoreboard players set player_num count_player 0
execute as @a run scoreboard players add player_num count_player 1

return run execute if score player_num count_player matches 1
