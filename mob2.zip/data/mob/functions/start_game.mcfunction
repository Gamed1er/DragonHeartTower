
execute as @s run tag @s add meet_tutor
execute as @s run tag @s add meet_tutor_1
kill @e[tag=direction_arrow]
function mob:mission_system/summon_direction_arrow
execute as @s run tp 4670.52 -57.00 4511.38
setworldspawn 4632 -57 4447
function mob:floor_enemey_summoner/floor_lock_reset
scoreboard players set tower control_panel 0
fill 4662 -56 4489 4656 -58 4489 oak_fence
fill 4594 -57 4464 4594 -54 4462 oak_fence
tag @a add have_not_entered_tower
function mob:give_op
time set noon