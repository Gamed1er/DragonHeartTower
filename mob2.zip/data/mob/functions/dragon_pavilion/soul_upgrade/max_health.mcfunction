execute if score @s dragon_soul >= max_health soul_upgrade_cost run tag @s add deal

title @s times 0t 10t 5t
execute unless score @s dragon_soul >= max_health soul_upgrade_cost run title @s subtitle ["",{"text":"[","bold":true,"italic":false,"color":"white"},{"translate":"ToDH.dragon_pavilion.soul_upgrade.dragon_soul_not_enough","bold":true,"italic":false,"underlined":true,"color":"red"},{"text":"]","bold":true,"italic":false,"color":"white"}]
playsound minecraft:block.lava.extinguish voice @s[tag=!deal] ~ ~ ~ 1 2
title @s title [""]

title @s times 0t 10t 5t
title @s[tag=deal] subtitle ["",{"text":"[","bold":true,"italic":false,"color":"white"},{"translate":"ToDH.dragon_pavilion.soul_upgrade.empowered_success","bold":true,"italic":false,"underlined":true,"color":"gold"},{"text":"]","bold":true,"italic":false,"color":"white"}]
execute as @s[tag=deal] at @s run playsound minecraft:entity.player.levelup voice @s ~ ~ ~
title @s title [""]

execute unless score @s max_health matches -1..9999 run scoreboard players set @s max_health 0
scoreboard players add @s[tag=deal] max_health 5
execute store result storage mob:function soul_upgrade.max_health float 0.01 run scoreboard players get @s[tag=deal] max_health
execute as @s[tag=deal] run function mob:dragon_pavilion/soul_upgrade/set_max_health with storage mob:function soul_upgrade

scoreboard players operation @s[tag=deal] dragon_soul -= max_health soul_upgrade_cost
execute as @s run function mob:dragon_pavilion/dragon_pavilion_soul_upgrade
tag @s remove deal


execute as @s store result storage mob:function dragon_soul.count int 1 run scoreboard players get @s dragon_soul
execute as @s run function mob:dragon_pavilion/dragon_soul_display with storage mob:function dragon_soul

