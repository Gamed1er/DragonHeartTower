tellraw @s [{"translate": "ToDH.message,next_page"}]
execute if score tower control_panel matches 1 run tp @s @e[limit=1,tag=tower_1,tag=spawn_point]
execute if score tower control_panel matches 2 run tp @s @e[limit=1,tag=tower_2,tag=spawn_point]
execute if score tower control_panel matches 3 run tp @s @e[limit=1,tag=tower_3,tag=spawn_point]
tag @s remove in_dragon_pavilion
#gamemode spectator @s

execute as @s store result storage mob:function soul_upgrade.attack_damage float 0.01 run scoreboard players get @s attack_damage
execute as @s store result storage mob:function soul_upgrade.max_health float 0.01 run scoreboard players get @s max_health
execute as @s run function mob:dragon_pavilion/soul_upgrade/set_max_health with storage mob:function soul_upgrade
execute as @s run function mob:dragon_pavilion/soul_upgrade/set_attack_damage with storage mob:function soul_upgrade
effect give @s regeneration 5 10
effect give @s instant_health 1 255