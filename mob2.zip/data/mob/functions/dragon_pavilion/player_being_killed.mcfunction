tag @s[tag=!have_not_entered_tower] add dead
tag @s[tag=!have_not_entered_tower] add in_dragon_pavilion
scoreboard players add @s player_dead_reborn 1
execute as @s run function mob:dragon_pavilion/claer
execute unless function mob:is_single_player run scoreboard players operation @s[tag=!have_not_entered_tower] reborn_cd = reborn_cd_set reborn_cd
execute unless function mob:is_single_player run scoreboard players operation @s[tag=!have_not_entered_tower] reborn_cd *= @s[tag=!have_not_entered_tower] player_dead_reborn
#schedule function mob:dragon_pavilion/late_clear 2t replace
advancement revoke @s only mob:player_dead
execute as @a[tag=!dead,tag=!have_not_entered_tower] if score remain_mob_amount floor_controller matches 1.. run function mob:floor_controller/fighting_lock_floor
scoreboard players set @s player_dead 0