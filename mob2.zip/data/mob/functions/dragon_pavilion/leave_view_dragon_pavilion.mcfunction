scoreboard players set @e[tag=homunculus] plot_type 0
tag @a remove in_dragon_pavilion
tag @a remove view_dragon_pavilion
tag @a remove test_dragon_pavilion