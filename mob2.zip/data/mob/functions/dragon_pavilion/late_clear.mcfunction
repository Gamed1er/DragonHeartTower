

execute as @a[tag=dead,tag=in_dragon_pavilion,tag=!have_not_entered_tower] if score @s reborn_cd matches 287.. run function mob:dragon_pavilion/claer