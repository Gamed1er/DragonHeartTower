execute as @e[tag=stairs,tag=tower_1] at @s positioned ~ ~-3 ~ run function mob:floor_controller/clear_area
execute as @e[tag=stairs,tag=tower_1,tag=floor_3] at @s positioned ~ ~45 ~ run function mob:floor_controller/clear_area
execute as @e[tag=stairs,tag=tower_1,tag=floor_6] at @s positioned ~ ~45 ~ run function mob:floor_controller/clear_area
execute as @e[tag=stairs,tag=tower_1,tag=floor_9] at @s positioned ~ ~45 ~ run function mob:floor_controller/clear_area
execute as @e[tag=stairs,tag=tower_1,tag=floor_10] at @s positioned ~ ~45 ~ run function mob:floor_controller/clear_area


execute as @e[tag=stairs,tag=tower_1,tag=floor_0] at @s run setblock ~ ~-2 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_safe",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_0] at @s run setblock ~ ~-2 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_1] at @s run setblock ~ ~-2 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_battle",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_1] at @s run setblock ~ ~-2 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_2] at @s run setblock ~ ~-2 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_battle",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_2] at @s run setblock ~ ~-2 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_3] at @s run setblock ~ ~-4 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_boss_part_1",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_3] at @s run setblock ~ ~-4 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_4] at @s run setblock ~ ~-2 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_battle",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_4] at @s run setblock ~ ~-2 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_5] at @s run setblock ~ ~-2 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_battle",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_5] at @s run setblock ~ ~-2 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_6] at @s run setblock ~ ~-4 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_boss_part_1",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_6] at @s run setblock ~ ~-4 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_7] at @s run setblock ~ ~-2 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_battle",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_7] at @s run setblock ~ ~-2 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_8] at @s run setblock ~ ~-2 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_battle",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_8] at @s run setblock ~ ~-2 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_9] at @s run setblock ~ ~-4 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_boss_part_1",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_9] at @s run setblock ~ ~-4 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_10] at @s run setblock ~ ~-4 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_boss_part_1",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_10] at @s run setblock ~ ~-4 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_3] at @s run setblock ~ ~44 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_boss_part_2",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_3] at @s run setblock ~ ~44 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_6] at @s run setblock ~ ~44 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_boss_part_2",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_6] at @s run setblock ~ ~44 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_9] at @s run setblock ~ ~44 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_boss_part_2",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_9] at @s run setblock ~ ~44 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_10] at @s run setblock ~ ~44 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_boss_part_2",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_10] at @s run setblock ~ ~44 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_3_5] at @s run setblock ~ ~-2 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_safe",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_3_5] at @s run setblock ~ ~-2 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_6_5] at @s run setblock ~ ~-2 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_safe",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_6_5] at @s run setblock ~ ~-2 ~-1 redstone_block
execute as @e[tag=stairs,tag=tower_1,tag=floor_9_5] at @s run setblock ~ ~-2 ~ minecraft:structure_block[mode=load]{ignoreEntities:0b,integrity:1.0f,metadata:"",mirror:"NONE",mode:"LOAD",name:"mob:tower_1_stairs_lock_safe",posX:-2,posY:0,posZ:-2,powered:0b,rotation:"NONE",seed:0L,showair:0b,showboundingbox:0b,sizeX:0,sizeY:0,sizeZ:0,}
execute as @e[tag=stairs,tag=tower_1,tag=floor_9_5] at @s run setblock ~ ~-2 ~-1 redstone_block
