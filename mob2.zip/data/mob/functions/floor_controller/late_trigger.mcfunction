execute as @e[tag=stairs,tag=tower_1] at @s run setblock ~ ~-3 ~ stone
execute as @e[tag=stairs,tag=tower_1,tag=floor_3] at @s run setblock ~ ~45 ~ stone
execute as @e[tag=stairs,tag=tower_1,tag=floor_6] at @s run setblock ~ ~45 ~ stone
execute as @e[tag=stairs,tag=tower_1,tag=floor_9] at @s run setblock ~ ~45 ~ stone
execute as @e[tag=stairs,tag=tower_1,tag=floor_10] at @s run setblock ~ ~45 ~ stone
