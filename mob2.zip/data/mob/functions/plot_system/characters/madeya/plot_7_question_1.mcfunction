execute as @s run scoreboard players set @s plot_progress 10
execute as @s store result storage todh:plot plot_progress int 1 run scoreboard players get @s plot_progress
scoreboard players set @s character 1
scoreboard players set @s plot_type 9
execute as @s run function mob:plot_system/plot_reader with storage todh:plot

execute as @a at @s run playsound minecraft:entity.arrow.hit_player voice @a ~ ~ ~
execute as @s run scoreboard players set @s plot_progress 8
execute as @s run scoreboard players set @s plot_type 2
execute as @s run function mob:plot_system/characters/madeya/main
