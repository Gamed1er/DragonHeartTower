execute as @s run scoreboard players set @s plot_progress 14
execute as @s run scoreboard players set @s plot_type 2
execute as @s run function mob:plot_system/characters/tokesor/main

execute as @a at @s run playsound minecraft:entity.arrow.hit_player voice @a ~ ~ ~