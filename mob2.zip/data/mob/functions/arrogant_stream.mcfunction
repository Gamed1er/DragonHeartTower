execute as @s[tag=flame_wizard] run function mob:mob_skill/wizards/flame_wizard
execute as @s[tag=water_wizard] run function mob:mob_skill/wizards/water_wizard
execute as @s[tag=earth_wizard] run function mob:mob_skill/wizards/earth_wizard
execute as @s[tag=wood_wizard] run function mob:mob_skill/wizards/wood_wizard
execute as @s[tag=flame_fairy] run function mob:mob_skill/element_fairy/flame_fairy
execute as @s[tag=water_fairy] run function mob:mob_skill/element_fairy/water_fairy
execute as @s[tag=earth_fairy] run function mob:mob_skill/element_fairy/earth_fairy
execute as @s[tag=wood_fairy] run function mob:mob_skill/element_fairy/wood_fairy
execute as @s[type=evoker_fangs] run function mob:mob_skill/wizards/evoker_fangs/main
execute as @s[type=vex,tag=!enemy] run function mob:mob_skill/wizards/vex/main
execute as @s[type=fireball] run function mob:mob_skill/wizards/evoker_fangs/flame_wizard_fireball
execute as @s[type=falling_block,tag=fallen_ice] run function mob:mob_skill/wizards/evoker_fangs/fallen_ice
execute as @s[tag=branches] run function mob:mob_skill/wizards/evoker_fangs/branches

execute as @s[tag=have_not_set_body_limit] run scoreboard players set @s stiff.bodylimit.Max 1000