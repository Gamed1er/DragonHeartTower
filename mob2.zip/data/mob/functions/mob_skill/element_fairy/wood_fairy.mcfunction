execute as @s if entity @s[tag=new_born] run item replace entity @s armor.head with moss_block 1
execute as @s if entity @s[tag=new_born] run item replace entity @s armor.chest with leather_chestplate 1
execute as @s if entity @s[tag=new_born] run item modify entity @s armor.chest mob:fairy/wood_fairy_chestplate
execute as @s if entity @s[tag=new_born] run item replace entity @s armor.legs with leather_leggings 1
execute as @s if entity @s[tag=new_born] run item modify entity @s armor.legs mob:fairy/wood_fairy_leggings
execute as @s if entity @s[tag=new_born] run item replace entity @s armor.feet with leather_boots 1
execute as @s if entity @s[tag=new_born] run item modify entity @s armor.feet mob:fairy/wood_fairy_boots
execute as @s if entity @s[tag=new_born] run item replace entity @s weapon.mainhand with wooden_axe 1
execute as @s if entity @s[tag=new_born] run item modify entity @s weapon.mainhand mob:fairy/wood_fairy_weapon
execute as @s if entity @s[tag=new_born] run data modify entity @s ArmorDropChances[3] set value 0f
tag @s remove new_born
