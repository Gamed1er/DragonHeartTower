execute as @s if entity @s[tag=new_born] run item replace entity @s armor.head with carved_pumpkin 1
execute as @s if entity @s[tag=new_born] run item modify entity @s armor.head mob:wizard/wood_wizard_hat
execute as @s if entity @s[tag=new_born] run item replace entity @s armor.chest with leather_chestplate 1
execute as @s if entity @s[tag=new_born] run item modify entity @s armor.chest mob:wizard/wizard_chestplate
execute as @s if entity @s[tag=new_born] run item replace entity @s armor.legs with leather_leggings 1
execute as @s if entity @s[tag=new_born] run item modify entity @s armor.legs mob:wizard/wizard_leggings
execute as @s if entity @s[tag=new_born] run item replace entity @s armor.feet with leather_boots 1
execute as @s if entity @s[tag=new_born] run item modify entity @s armor.feet mob:wizard/wizard_boots
execute as @s if entity @s[tag=new_born] run item replace entity @s weapon.offhand with totem_of_undying 1
#execute as @s if entity @s[tag=new_born] run data modify entity @s ArmorDropChances set value [1f,1f,1f,1f]
tag @s remove new_born


execute as @s run function mob:mob_skill/wizards/vex/wood_field