execute as @s if score @s frost_field_time matches 0.. run scoreboard players remove @s frost_field_time 1
execute as @s if score @s frost_field_time matches 0.. at @s run particle snowflake ~ ~ ~ 3 0.5 3 0.01 40 force
execute as @s if score @s frost_field_time matches 0.. at @s run effect give @a[distance=..8] slowness 1 2
execute as @s if score @s frost_field_time matches 0.. at @s run effect give @a[distance=..8] weakness 1 0
execute as @s if score @s frost_field_time matches 0.. at @s run effect give @a[distance=..8] mining_fatigue 1 2
execute as @s if score @s frost_field_time matches 0.. at @s rotated as @e[type=marker,tag=rotate_marker,limit=1] run particle dust 0.373 0.38 0.969 2 ^ ^0.5 ^8 0 0 0 0 10 force
execute as @s if score @s frost_field_time matches 0.. at @s rotated as @e[type=marker,tag=rotate_marker,limit=1] run particle dust 0.373 0.38 0.969 2 ^ ^0.5 ^-8 0 0 0 0 10 force