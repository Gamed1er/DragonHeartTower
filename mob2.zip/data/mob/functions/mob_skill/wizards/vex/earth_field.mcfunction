execute as @s if score @s earth_field_time matches 0.. run scoreboard players remove @s earth_field_time 1
execute as @s if score @s earth_field_time matches 99 at @s run function mob:summon_mob/elements_fairy/earth_fairy
execute as @s if score @s earth_field_time matches 99 at @s run function mob:summon_mob/elements_fairy/earth_fairy
execute as @s if score @s earth_field_time matches 0.. at @s run particle dust 0.871 0.737 0.141 1 ~ ~ ~ 3 0 3 0.01 40 force
execute as @s if score @s earth_field_time matches 0.. at @s run effect give @e[type=#arrogant_mob,distance=..7.5] resistance 5 2
execute as @s if score @s earth_field_time matches 0.. at @s rotated as @e[type=marker,tag=rotate_marker,limit=1] run particle dust 0.439 0.318 0.055 2 ^ ^0.5 ^8 0 0 0 0 10 force
execute as @s if score @s earth_field_time matches 0.. at @s rotated as @e[type=marker,tag=rotate_marker,limit=1] run particle dust 0.439 0.318 0.055 2 ^ ^0.5 ^-8 0 0 0 0 10 force
