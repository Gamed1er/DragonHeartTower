execute as @s if score @s wood_field_time matches 0.. run scoreboard players remove @s wood_field_time 1
execute as @s if score @s wood_field_time matches 59 at @s run function mob:summon_mob/elements_fairy/wood_fairy
execute as @s if score @s wood_field_time matches 59 at @s run function mob:summon_mob/elements_fairy/wood_fairy
execute as @s if score @s wood_field_time matches 59 at @s run function mob:summon_mob/elements_fairy/wood_fairy
execute as @s if score @s wood_field_time matches 59 at @s run function mob:summon_mob/elements_fairy/wood_fairy
execute as @s if score @s wood_field_time matches 0.. at @s run particle dust 0.647 0.961 0.42 1 ~ ~ ~ 3 0 3 0.01 40 force
execute as @s if score @s wood_field_time matches 0.. at @s run effect give @e[type=#arrogant_mob,distance=..7.5] regeneration 1 3
execute as @s if score @s wood_field_time matches 0.. at @s rotated as @e[type=marker,tag=rotate_marker,limit=1] run particle dust 0.059 0.38 0.184 2 ^ ^0.5 ^8 0 0 0 0 10 force
execute as @s if score @s wood_field_time matches 0.. at @s rotated as @e[type=marker,tag=rotate_marker,limit=1] run particle dust 0.059 0.38 0.184 2 ^ ^0.5 ^-8 0 0 0 0 10 force
