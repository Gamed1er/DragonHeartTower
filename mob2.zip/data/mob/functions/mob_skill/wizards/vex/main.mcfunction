execute on origin if entity @s[tag=flame_wizard] as @s run scoreboard players set @s resistance_fire_ring_keep_time 0
execute on origin if entity @s[tag=water_wizard] as @s run scoreboard players set @s frost_field_time 200
execute on origin if entity @s[tag=earth_wizard] as @s run scoreboard players set @s earth_field_time 100
execute on origin if entity @s[tag=wood_wizard] as @s run scoreboard players set @s wood_field_time 60

tp @s ~ ~-100 ~
kill @s