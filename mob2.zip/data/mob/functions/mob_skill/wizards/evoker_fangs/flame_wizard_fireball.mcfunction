
execute as @s[tag=flame_wizard_fireball] store result entity @s Motion[0] double 0.008 run scoreboard players get @s Motion_X2
execute as @s[tag=flame_wizard_fireball] store result entity @s Motion[1] double 0.008 run scoreboard players get @s Motion_Y2
execute as @s[tag=flame_wizard_fireball] store result entity @s Motion[2] double 0.008 run scoreboard players get @s Motion_Z2

execute as @s[tag=flame_wizard_fireball] if entity @s[nbt={PortalCooldown:0}] run kill @s 