execute as @e[type=evoker,tag=flame_wizard,tag=release_fireball] run function mob:mob_skill/wizards/evoker_fangs/flame_wizard
