scoreboard players remove @s branches_life_time 1
execute if score @s branches_life_time matches ..-15 at @s as @a[distance=..1.5] run function mob:mob_skill/wizards/evoker_fangs/branches_bound
execute if score @s branches_life_time matches ..-25 run kill @s
execute if score @s branches_life_time matches ..-15 at @s run particle dust 0.059 0.38 0.184 0.5 ~ ~ ~ 0 0.4 0 0 40 force
execute if score @s branches_life_time matches ..-15 at @s run particle dust 0.18 0.882 0.451 1 ~ ~ ~ 0.05 0.8 0.05 0 40 force
execute at @s run particle block stone ~ ~ ~ 0 0 0 0 20 force
