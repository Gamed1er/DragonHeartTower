effect give @s slowness 3 15 true
effect give @s jump_boost 3 252 true
damage @s 1 mob_attack by @e[type=marker,tag=branches,sort=nearest,limit=1]