
execute as @s at @s run tp @s ~ ~ ~ facing entity @p
execute as @s at @s run tp @s ^ ^ ^0.1

execute at @s positioned ^ ^ ^ run summon fireball ^ ^ ^0.5 {Tags:[flame_wizard_fireball,new_born],ExplosionPower:2,PortalCooldown:100}
execute as @s at @s positioned ^ ^ ^0.5 run data modify entity @e[type=fireball,tag=flame_wizard_fireball,tag=new_born,sort=nearest,limit=1] Owner set from entity @s UUID

execute as @s at @s store result score @e[type=fireball,tag=flame_wizard_fireball,tag=new_born,sort=nearest,limit=1] Motion_X run data get entity @s Pos[0] 1000
execute as @s at @s store result score @e[type=fireball,tag=flame_wizard_fireball,tag=new_born,sort=nearest,limit=1] Motion_Y run data get entity @s Pos[1] 1000
execute as @s at @s store result score @e[type=fireball,tag=flame_wizard_fireball,tag=new_born,sort=nearest,limit=1] Motion_Z run data get entity @s Pos[2] 1000

execute as @s at @s run tp @s ^ ^ ^0.1

execute as @s at @s store result score @e[type=fireball,tag=flame_wizard_fireball,tag=new_born,sort=nearest,limit=1] Motion_X2 run data get entity @s Pos[0] 1000
execute as @s at @s store result score @e[type=fireball,tag=flame_wizard_fireball,tag=new_born,sort=nearest,limit=1] Motion_Y2 run data get entity @s Pos[1] 1000
execute as @s at @s store result score @e[type=fireball,tag=flame_wizard_fireball,tag=new_born,sort=nearest,limit=1] Motion_Z2 run data get entity @s Pos[2] 1000

execute at @s as @e[type=fireball,tag=flame_wizard_fireball,tag=new_born,sort=nearest,limit=1] run scoreboard players operation @s Motion_X2 -= @s Motion_X
execute at @s as @e[type=fireball,tag=flame_wizard_fireball,tag=new_born,sort=nearest,limit=1] run scoreboard players operation @s Motion_Y2 -= @s Motion_Y
execute at @s as @e[type=fireball,tag=flame_wizard_fireball,tag=new_born,sort=nearest,limit=1] run scoreboard players operation @s Motion_Z2 -= @s Motion_Z

execute at @s as @e[type=fireball,tag=flame_wizard_fireball,tag=new_born,sort=nearest,limit=1] run tag @s remove new_born
tag @s remove release_fireball