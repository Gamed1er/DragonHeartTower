execute on origin if entity @s[tag=flame_wizard] as @s run tag @s add release_fireball
execute on origin if entity @s[tag=flame_wizard] as @s run schedule function mob:mob_skill/wizards/evoker_fangs/flame_wizard_late 1t replace
execute on origin if entity @s[tag=water_wizard] as @s run tag @s add release_fallen_ice
execute on origin if entity @s[tag=water_wizard] as @s run schedule function mob:mob_skill/wizards/evoker_fangs/water_wizard_fallen_ice_late 1t replace
execute on origin if entity @s[tag=wood_wizard] as @s run tag @s add release_branches_bound
execute on origin if entity @s[tag=wood_wizard] as @s run schedule function mob:mob_skill/wizards/evoker_fangs/wood_wizard_branches_bound_late 1t replace


execute at @s on origin if entity @s[tag=!earth_wizard] run tp @e[type=evoker_fangs,sort=nearest,limit=1] ~ ~-100 ~
execute at @s on origin if entity @s[tag=!earth_wizard] run kill @e[type=evoker_fangs,sort=nearest,limit=1]