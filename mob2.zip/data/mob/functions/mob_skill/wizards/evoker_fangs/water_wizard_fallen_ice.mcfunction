execute at @s as @a[distance=..12] at @s run summon falling_block ~ ~4 ~ {DropItem:false,BlockState:{Name:"minecraft:blue_ice"},CancelDrop:true,Tags:[fallen_ice]}
