execute at @s as @a[distance=..10] at @s run function mob:summon_mob/branches
