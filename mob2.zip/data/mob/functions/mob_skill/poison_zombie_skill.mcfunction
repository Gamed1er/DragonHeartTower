execute if score tick time matches 0 at @s run summon area_effect_cloud ~ ~ ~ {Duration:40,Color:5351241,Radius:2.7f,effects:[{id:"minecraft:poison",amplifier:0,duration:40}],Tags:[poison]}
execute if score tick time matches 5 at @s run summon area_effect_cloud ~ ~ ~ {Duration:40,Color:5351241,Radius:2.7f,effects:[{id:"minecraft:poison",amplifier:0,duration:40}],Tags:[poison]}
execute if score tick time matches 10 at @s run summon area_effect_cloud ~ ~ ~ {Duration:40,Color:5351241,Radius:2.7f,effects:[{id:"minecraft:poison",amplifier:0,duration:40}],Tags:[poison]}
execute if score tick time matches 15 at @s run summon area_effect_cloud ~ ~ ~ {Duration:40,Color:5351241,Radius:2.7f,effects:[{id:"minecraft:poison",amplifier:0,duration:40}],Tags:[poison]}
