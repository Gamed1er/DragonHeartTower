
execute run data modify storage floor_gen:function room_pos set value "corner"
execute run data modify storage floor_gen:function posX set value -10
execute run data modify storage floor_gen:function posZ set value -10
execute run data modify storage floor_gen:function rotation set value "NONE"
execute store result storage floor_gen:function type int 1 run random value 0..3
execute at @s positioned ~21 ~-2 ~21 run function mob:floor_gen/set_structure_block with storage floor_gen:function


execute run data modify storage floor_gen:function room_pos set value "side"
execute run data modify storage floor_gen:function posX set value -10
execute run data modify storage floor_gen:function posZ set value -10
execute run data modify storage floor_gen:function rotation set value "NONE"
execute store result storage floor_gen:function type int 1 run random value 0..3
execute at @s positioned ~ ~-2 ~21 run function mob:floor_gen/set_structure_block with storage floor_gen:function


execute run data modify storage floor_gen:function room_pos set value "corner"
execute run data modify storage floor_gen:function posX set value 10
execute run data modify storage floor_gen:function posZ set value -10
execute run data modify storage floor_gen:function rotation set value "CLOCKWISE_90"
execute store result storage floor_gen:function type int 1 run random value 0..3
execute at @s positioned ~-21 ~-2 ~21 run function mob:floor_gen/set_structure_block with storage floor_gen:function

execute run data modify storage floor_gen:function room_pos set value "side"
execute run data modify storage floor_gen:function posX set value 10
execute run data modify storage floor_gen:function posZ set value -10
execute run data modify storage floor_gen:function rotation set value "CLOCKWISE_90"
execute store result storage floor_gen:function type int 1 run random value 0..3
execute at @s positioned ~-21 ~-2 ~ run function mob:floor_gen/set_structure_block with storage floor_gen:function

execute run data modify storage floor_gen:function room_pos set value "corner"
execute run data modify storage floor_gen:function posX set value 10
execute run data modify storage floor_gen:function posZ set value 10
execute run data modify storage floor_gen:function rotation set value "CLOCKWISE_180"
execute store result storage floor_gen:function type int 1 run random value 0..3
execute at @s positioned ~-21 ~-2 ~-21 run function mob:floor_gen/set_structure_block with storage floor_gen:function

execute run data modify storage floor_gen:function room_pos set value "side"
execute run data modify storage floor_gen:function posX set value 10
execute run data modify storage floor_gen:function posZ set value 10
execute run data modify storage floor_gen:function rotation set value "CLOCKWISE_180"
execute store result storage floor_gen:function type int 1 run random value 0..3
execute at @s positioned ~ ~-2 ~-21 run function mob:floor_gen/set_structure_block with storage floor_gen:function

execute run data modify storage floor_gen:function room_pos set value "corner"
execute run data modify storage floor_gen:function posX set value -10
execute run data modify storage floor_gen:function posZ set value 10
execute run data modify storage floor_gen:function rotation set value "COUNTERCLOCKWISE_90"
execute store result storage floor_gen:function type int 1 run random value 0..3
execute at @s positioned ~21 ~-2 ~-21 run function mob:floor_gen/set_structure_block with storage floor_gen:function

execute run data modify storage floor_gen:function room_pos set value "side"
execute run data modify storage floor_gen:function posX set value -10
execute run data modify storage floor_gen:function posZ set value 10
execute run data modify storage floor_gen:function rotation set value "COUNTERCLOCKWISE_90"
execute store result storage floor_gen:function type int 1 run random value 0..3
execute at @s positioned ~21 ~-2 ~ run function mob:floor_gen/set_structure_block with storage floor_gen:function

execute if score floor floor_gen matches 1 run tag @e[type=marker,tag=mob_summon_point,tag=unset] add floor_1
execute if score floor floor_gen matches 1 run tag @e[type=marker,tag=mob_summon_point,tag=unset] remove unset
execute if score floor floor_gen matches 2 run tag @e[type=marker,tag=mob_summon_point,tag=unset] add floor_2
execute if score floor floor_gen matches 2 run tag @e[type=marker,tag=mob_summon_point,tag=unset] remove unset
execute if score floor floor_gen matches 3 run tag @e[type=marker,tag=mob_summon_point,tag=unset] add floor_4
execute if score floor floor_gen matches 3 run tag @e[type=marker,tag=mob_summon_point,tag=unset] remove unset
execute if score floor floor_gen matches 4 run tag @e[type=marker,tag=mob_summon_point,tag=unset] add floor_5
execute if score floor floor_gen matches 4 run tag @e[type=marker,tag=mob_summon_point,tag=unset] remove unset
execute if score floor floor_gen matches 5 run tag @e[type=marker,tag=mob_summon_point,tag=unset] add floor_7
execute if score floor floor_gen matches 5 run tag @e[type=marker,tag=mob_summon_point,tag=unset] remove unset
execute if score floor floor_gen matches 6 run tag @e[type=marker,tag=mob_summon_point,tag=unset] add floor_8
execute if score floor floor_gen matches 6 run tag @e[type=marker,tag=mob_summon_point,tag=unset] remove unset
execute run scoreboard players add floor floor_gen 1
execute if score floor floor_gen matches ..6 run function mob:floor_gen/main