data merge storage floor_gen:function {posX:-10,posZ:-10,rotation:"NONE",tower:1,type:1,room_pos:"corner"}
execute if score floor floor_gen matches 0 run kill @e[type=marker,tag=mob_summon_point,tag=!unset,tag=!boss_room]
execute if score floor floor_gen matches 0 run scoreboard players set floor floor_gen 1
execute if score floor floor_gen matches 1 as @e[type=marker,tag=floor_1,tag=center] run function mob:floor_gen/stream
execute if score floor floor_gen matches 2 as @e[type=marker,tag=floor_2,tag=center] run function mob:floor_gen/stream
execute if score floor floor_gen matches 3 as @e[type=marker,tag=floor_4,tag=center] run function mob:floor_gen/stream
execute if score floor floor_gen matches 4 as @e[type=marker,tag=floor_5,tag=center] run function mob:floor_gen/stream
execute if score floor floor_gen matches 5 as @e[type=marker,tag=floor_7,tag=center] run function mob:floor_gen/stream
execute if score floor floor_gen matches 6 as @e[type=marker,tag=floor_8,tag=center] run function mob:floor_gen/stream
kill @e[type=item]
execute if score floor floor_gen matches 5 run function mob:floor_gen/refresh_eq
scoreboard players set @a player_dead_reborn 0