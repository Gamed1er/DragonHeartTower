execute as @e[type=marker,tag=eq_point] at @s run data modify block ~ ~ ~ LootTable set value "mob:resentment_normal_box"
execute as @e[type=marker,tag=eq_point] at @s run data modify block ~ ~-1 ~ LootTable set value "mob:resentment_normal_box"
