scoreboard players operation @s reborn_cd_sc = @s reborn_cd
scoreboard players operation @s reborn_cd_sc /= 20 math

#execute as @s run function mob:plot_system/characters/tool/rotation
execute as @s[advancements={mob:player_dead = true}] run function mob:dragon_pavilion/player_being_killed
execute as @s unless score @s ID_system matches 0.. store result score @s ID_system run scoreboard players add world_ID ID_system 1
execute as @s[gamemode=adventure,tag=in_tower] run function mob:floor_controller/main
execute as @s[gamemode=creative,tag=in_tower] run function mob:floor_controller/main
execute as @s if score @s reborn_cd matches 1.. run scoreboard players remove @s reborn_cd 1
#execute as @s[tag=dead,tag=!in_dragon_pavilion] if score @s reborn_cd matches 0 unless score alive_player control_panel matches 1.. at @e[tag=spawn_point] run tp @s ~ ~ ~
#execute as @s[tag=dead] at @s unless block ~ ~ ~ air unless block ~ ~ ~ water run tp @s @a[tag=!dead,limit=1]

#PLAYER DEATH CONTROL
execute if entity @s[tag=!dead,tag=!wait_reborn] run scoreboard players add alive_player control_panel 1
#execute if score @s[tag=!in_dragon_pavilion] reborn_cd matches ..1 run gamemode adventure @s[gamemode=spectator,tag=dead]
execute if score @s[tag=dead] reborn_cd matches 1 if score alive_player control_panel matches 1.. unless function mob:is_single_player run tag @s add wait_reborn
execute if score @s[tag=!in_dragon_pavilion,tag=dead] reborn_cd matches 0 if score alive_player control_panel matches 0 unless function mob:is_single_player run tag @s remove dead
execute if score @s[tag=dead] reborn_cd matches 1 if score alive_player control_panel matches 0 if function mob:is_single_player run tag @s remove dead
tellraw @s[tag=!in_dragon_pavilion,tag=wait_reborn] [{"translate":"ToDH.reborn"},{"color":"green","translate":"ToDH.reborn_button","clickEvent": {"action": "run_command","value": "/execute as @s run function mob:reborn"}}]
tag @s[tag=!in_dragon_pavilion,tag=wait_reborn] remove wait_reborn

execute as @s run function mob:action_bar_display/main
execute if predicate mob:hold_detect/hold_wood_fairy_weapon run effect give @s regeneration 1 0 
execute as @s[tag=!in_tower,tag=!have_not_entered_tower] run tp 4829.80 -59.00 4273.25
execute as @s[tag=!in_tower,tag=!have_not_entered_tower] run clear
execute as @s[tag=!in_tower,tag=!have_not_entered_tower] run tellraw @s [{"color":"aqua","text":"本地圖使用AmberWat的NegativeSpaceFont。"},{"color": "green","text":"[點此訪問]","clickEvent": {"action":"open_url","value": "https://github.com/AmberWat/NegativeSpaceFont"}}]
execute as @s[tag=!in_tower,tag=!have_not_entered_tower] run tag @s add have_not_entered_tower


execute positioned 4909.39 -59.00 4149.77 as @s[tag=late_homunculus_plot_countinue,distance=..5] run function mob:mission_system/missions/late_homunculus_plot_countinue
execute if score now_floor floor_controller matches 30 run effect give @s night_vision 10 0 true
execute if score now_floor floor_controller matches 60 run effect give @s night_vision 10 0 true
execute if score now_floor floor_controller matches 90 run effect give @s night_vision 10 0 true
execute if score now_floor floor_controller matches 100 run effect give @s night_vision 10 0 true

execute if score @s[tag=in_tower] reborn_cd matches 1.. as @s run title @s[tag=!in_dragon_pavilion] times 0t 1s 0t
execute if score @s[tag=in_tower] reborn_cd matches 1.. as @s unless function mob:is_single_player run title @s[tag=!in_dragon_pavilion] title [{"translate":"ToDH.reborn_cd","with":[{"score":{"name": "@s","objective": "reborn_cd_sc"}}]}]
execute if score @s[tag=in_tower] player_dead matches 1.. as @s[tag=in_tower,tag =!have_not_entered_tower] run advancement grant @s only mob:player_dead
execute if score @s[tag=in_tower] player_dead matches 1.. as @s[tag=in_tower,tag =!have_not_entered_tower] run scoreboard players set @s player_dead 0
