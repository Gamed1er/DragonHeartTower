
scoreboard players operation direction_arrow_count ID_system = world_ID ID_system
function mob:mission_system/summon_direction_arrow_loop