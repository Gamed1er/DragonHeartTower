summon item_display ~ ~ ~ {item:{id:"minecraft:coal",Count:1,tag:{CustomModelData:999}},item_display:"thirdperson_righthand",transformation:{left_rotation:[1f,0f,0f,0f],right_rotation:[0f,0f,1f,0f],scale:[1f,1f,1f],translation:[0f,0f,0f]},Tags:[direction_arrow],teleport_duration:1}
execute as @e[type=item_display,tag=direction_arrow] unless score @s ID_system matches 1.. at @s run scoreboard players operation @s ID_system = direction_arrow_count ID_system
scoreboard players remove direction_arrow_count ID_system 1
execute if score direction_arrow_count ID_system matches 1.. run function mob:mission_system/summon_direction_arrow_loop
execute as @e[type=item_display,tag=direction_arrow] run tp @s ~ ~-10 ~