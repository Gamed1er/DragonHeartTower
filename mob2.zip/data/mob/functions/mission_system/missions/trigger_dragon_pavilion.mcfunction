setworldspawn 4909 -59 4149
spawnpoint @a 4909 -59 4149
tp @a 4909.39 -59.00 4149.77
clear @a
kill @a
schedule function mob:mission_system/missions/late_homunculus_plot_countinue 10t