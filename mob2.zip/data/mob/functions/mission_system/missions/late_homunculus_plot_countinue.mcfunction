
scoreboard players set @e[tag=homunculus] plot_progress 22
scoreboard players set @e[tag=homunculus] plot_type 0
tp @a 4909.39 -59.00 4149.77
tag @a remove late_homunculus_plot_countinue
scoreboard players set @a reborn_cd 0